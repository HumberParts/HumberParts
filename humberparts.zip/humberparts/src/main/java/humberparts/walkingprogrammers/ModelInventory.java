package humberparts.walkingprogrammers;

/**
 * Created by Ash on 2016-11-13.
 */

public class ModelInventory {
    private String id;
    private String name;
    private String stocks;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStocks() {
        return stocks;
    }

    public void setStocks(String stocks) {
        this.stocks = stocks;
    }
}
